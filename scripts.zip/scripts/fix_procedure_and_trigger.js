#!/usr/bin/env node
import mysql from 'mysql2/promise';

(async function main(){
  const cfg = {
    host: 'localhost',
    user: 'root',
    password: 'vishal36646',
    database: 'ev_charging_system',
    multipleStatements: true,
  };

  let conn;
  try {
    conn = await mysql.createConnection(cfg);
    console.log('Connected to MySQL for migration');

    // 1) Replace create_booking procedure so it only inserts booking row
    const dropProc = `DROP PROCEDURE IF EXISTS create_booking;`;
    const createProc = `
    CREATE PROCEDURE create_booking(
      IN p_user_id INT,
      IN p_vehicle_id INT,
      IN p_slot_id INT,
      IN p_booking_date DATE,
      IN p_start_time TIME,
      IN p_end_time TIME
    )
    BEGIN
      INSERT INTO bookings (user_id, vehicle_id, slot_id, booking_date, start_time, end_time, status)
      VALUES (p_user_id, p_vehicle_id, p_slot_id, p_booking_date, p_start_time, p_end_time, 'confirmed');
    END;
    `;

    console.log('Dropping existing procedure (if any)');
    await conn.query(dropProc);
    console.log('Creating new create_booking procedure (procedure will only insert booking row)');
    await conn.query(createProc);

    // 2) Recreate the AFTER INSERT trigger to update slot status and insert into charger_usage_log
    const dropTrig = `DROP TRIGGER IF EXISTS trg_after_booking_insert;`;
    const createTrig = `
    CREATE TRIGGER trg_after_booking_insert
    AFTER INSERT ON bookings
    FOR EACH ROW
    BEGIN
      DECLARE v_station_id INT;
      SELECT station_id INTO v_station_id FROM slots WHERE slot_id = NEW.slot_id;
      UPDATE slots SET status = 'booked' WHERE slot_id = NEW.slot_id;
      INSERT INTO charger_usage_log (slot_id, station_id, user_id, booking_id, start_time, end_time, status)
      VALUES (NEW.slot_id, v_station_id, NEW.user_id, NEW.booking_id, NOW(), DATE_ADD(NOW(), INTERVAL 10 MINUTE), 'in_use');
    END;
    `;

    console.log('Dropping existing trigger (if any)');
    await conn.query(dropTrig);
    console.log('Creating trg_after_booking_insert trigger');
    await conn.query(createTrig);

    // 3) Verify trigger exists
    const [rows] = await conn.query("SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'trg_after_booking_insert'");
    if (rows && rows.length > 0) {
      console.log('Trigger created:', rows[0].TRIGGER_NAME);
    } else {
      console.warn('Trigger not found after creation (unexpected)');
    }

    // 4) Show procedure source (sanity)
    const [procRows] = await conn.query("SHOW CREATE PROCEDURE create_booking");
    if (procRows && procRows[0]) {
      console.log('Procedure create_booking definition (truncated):');
      console.log(procRows[0]['Create Procedure'].slice(0, 400) + '...');
    }

    console.log('Migration completed successfully');
    await conn.end();
    process.exit(0);
  } catch (err) {
    console.error('Migration failed:', err && err.message ? err.message : err);
    if (conn) await conn.end().catch(()=>{});
    process.exit(1);
  }
})();
