import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';

(async function(){
  const cfg = { host: 'localhost', user: 'root', password: 'vishal36646', database: 'ev_charging_system' };
  try {
    const db = await mysql.createConnection(cfg);
    console.log('Connected to DB');

    // Find users whose password doesn't look like bcrypt ($2a$,$2b$,$2y$)
    const [rows] = await db.execute("SELECT user_id, password, email FROM users");
    let updated = 0;
    for (const r of rows) {
      const pw = r.password || '';
      if (!pw.startsWith('$2a$') && !pw.startsWith('$2b$') && !pw.startsWith('$2y$') && pw.length > 0) {
        // treat as plaintext -> hash
        const hash = bcrypt.hashSync(pw, 10);
        await db.execute('UPDATE users SET password = ? WHERE user_id = ?', [hash, r.user_id]);
        console.log('Upgraded password for', r.email || r.user_id);
        updated++;
      }
    }

    console.log('Completed. Passwords upgraded:', updated);
    await db.end();
    process.exit(0);
  } catch (err) {
    console.error('Error', err.message || err);
    process.exit(2);
  }
})();
