import mysql from 'mysql2/promise';

async function seed() {
  const conn = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'vishal36646',
    database: 'ev_charging_system'
  });

  try {
    // Detect columns on stations
    const [cols] = await conn.execute("SHOW COLUMNS FROM stations");
    const colNames = cols.map(c => c.Field);

    // Prepare station data depending on available columns
    const stationData = {
      station_name: 'Demo Station',
      address: 'Demo City',
      contact_no: '0000000000',
      location: 'Demo Location',
      image: 'https://via.placeholder.com/800x400',
      latitude: null,
      longitude: null,
      total_slots: 4,
      available_slots: 4
    };

    const stationCols = [];
    const stationVals = [];
    for (const k of Object.keys(stationData)) {
      if (colNames.includes(k)) {
        stationCols.push(k);
        stationVals.push(stationData[k]);
      }
    }

    const placeholders = stationVals.map(_ => '?').join(',');
    const stationSql = `INSERT INTO stations (${stationCols.join(',')}) VALUES (${placeholders})`;
    const [stationRes] = await conn.execute(stationSql, stationVals);
    const stationId = stationRes.insertId;

    // Insert a slot (ensure slots table has expected columns)
    const [slotColsRows] = await conn.execute('SHOW COLUMNS FROM slots');
    const slotCols = slotColsRows.map(r => r.Field);
    const slotInsertCols = ['station_id', 'slot_number', 'status'].filter(c => slotCols.includes(c));
    const slotPlaceholders = slotInsertCols.map(_ => '?').join(',');
    const slotSql = `INSERT INTO slots (${slotInsertCols.join(',')}) VALUES (${slotPlaceholders})`;
    const slotVals = [stationId, 'S1', 'available'].slice(0, slotInsertCols.length);
    const [slotRes] = await conn.execute(slotSql, slotVals);
    const slotId = slotRes.insertId;

    console.log(JSON.stringify({ stationId, slotId }));
  } catch (err) {
    console.error('Seed error', err.message || err);
    process.exit(1);
  } finally {
    await conn.end();
  }
}

seed();
