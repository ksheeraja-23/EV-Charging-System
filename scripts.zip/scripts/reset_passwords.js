#!/usr/bin/env node
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';

/*
  Usage:
    node scripts/reset_passwords.js --password "NewPass123" --all
    node scripts/reset_passwords.js --password "NewPass123" --email user@example.com

  This script WILL NOT store plaintext passwords. It will hash the provided plaintext
  using bcrypt and replace the stored password with the bcrypt hash so users can
  login with the provided password. This is safer than storing plaintext in DB.
*/

const argv = yargs(hideBin(process.argv))
  .option('password', { type: 'string', demandOption: true, describe: 'Plaintext password to set (will be hashed)' })
  .option('all', { type: 'boolean', describe: 'Reset for all users' })
  .option('email', { type: 'string', describe: 'Reset password for a single user by email' })
  .help()
  .argv;

const cfg = { host: 'localhost', user: 'root', password: 'vishal36646', database: 'ev_charging_system' };

(async function(){
  try {
    const db = await mysql.createConnection(cfg);
    const pwd = argv.password;
    const hash = bcrypt.hashSync(pwd, 10);

    if (argv.all) {
      const [r] = await db.execute('UPDATE users SET password = ? WHERE 1', [hash]);
      console.log('Updated passwords for all users');
    } else if (argv.email) {
      const [r] = await db.execute('UPDATE users SET password = ? WHERE email = ?', [hash, argv.email]);
      console.log(`Updated password for ${argv.email}`);
    } else {
      console.error('Specify --all or --email user@example.com');
      process.exit(2);
    }

    await db.end();
    process.exit(0);
  } catch (err) {
    console.error('Error', err.message || err);
    process.exit(3);
  }
})();
