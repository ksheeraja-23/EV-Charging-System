import mysql from 'mysql2/promise';
(async function(){
  try {
    const db = await mysql.createConnection({ host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' });
    // Add is_complaint boolean and pump_identifier if not exists
    const [cols] = await db.execute("SHOW COLUMNS FROM feedback LIKE 'is_complaint'");
    if (cols.length === 0) {
      await db.execute("ALTER TABLE feedback ADD COLUMN is_complaint TINYINT(1) DEFAULT 0 AFTER comment");
      console.log('Added is_complaint column');
    } else console.log('is_complaint already present');

    const [cols2] = await db.execute("SHOW COLUMNS FROM feedback LIKE 'pump_identifier'");
    if (cols2.length === 0) {
      await db.execute("ALTER TABLE feedback ADD COLUMN pump_identifier VARCHAR(255) DEFAULT NULL AFTER is_complaint");
      console.log('Added pump_identifier column');
    } else console.log('pump_identifier already present');

    await db.end();
    process.exit(0);
  } catch (err) {
    console.error('Error', err.message || err);
    process.exit(2);
  }
})();
