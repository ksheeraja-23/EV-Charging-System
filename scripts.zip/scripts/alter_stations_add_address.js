import mysql from 'mysql2/promise';

async function run() {
  let conn;
  try {
    conn = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'vishal36646',
      database: 'ev_charging_system',
    });

    // check if address column exists
    const [cols] = await conn.execute("SHOW COLUMNS FROM stations LIKE 'address'");
    if (cols && cols.length > 0) {
      console.log('Column `address` already exists on stations table.');
      return;
    }

    console.log('Adding `address` column to stations table...');
    await conn.execute("ALTER TABLE stations ADD COLUMN address VARCHAR(255) DEFAULT NULL");
    console.log('Added `address` column.');
  } catch (err) {
    console.error('Migration failed:', err.message || err);
    process.exitCode = 1;
  } finally {
    if (conn) await conn.end();
  }
}

run();
