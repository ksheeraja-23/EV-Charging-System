import mysql from 'mysql2/promise';

async function printCols(table) {
  const conn = await mysql.createConnection({ host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' });
  try {
    const [rows] = await conn.execute(`SHOW COLUMNS FROM ${table}`);
    console.log(`Columns for ${table}:`, rows.map(r => r.Field).join(', '));
  } catch (err) {
    console.error(`Error for ${table}:`, err.message || err);
  } finally {
    await conn.end();
  }
}

await printCols('stations');
await printCols('slots');
await printCols('users');
