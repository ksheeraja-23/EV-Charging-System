import mysql from 'mysql2/promise';

(async function(){
  try {
    const db = await mysql.createConnection({
      host: 'localhost', user: 'root', password: 'vishal36646', database: 'ev_charging_system'
    });
    const email = process.argv[2] || 'admin@example.com';
    // If user exists, update role; otherwise insert new admin user with hashed password placeholder
    const [rows] = await db.execute('SELECT user_id FROM users WHERE email = ?', [email]);
    if (rows.length > 0) {
      const uid = rows[0].user_id;
      await db.execute('UPDATE users SET role = ? WHERE user_id = ?', ['admin', uid]);
      console.log('Updated existing user', email, 'to admin');
    } else {
      const [r] = await db.execute('INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)', ['Admin User', email, 'adminpass', 'admin']);
      console.log('Created admin user with id', r.insertId, 'email', email);
    }
    await db.end();
  } catch (err) {
    console.error('Error', err.message || err);
    process.exit(1);
  }
})();
