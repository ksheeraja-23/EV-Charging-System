import mysql from 'mysql2/promise';

const updates = [
  { name: 'GreenCharge Pune - Kalyani Nagar', address: 'Survey 45, Kalyani Nagar, Pune, Maharashtra 411014, India' },
  { name: 'CityVolt Hinjewadi', address: 'Phase 3, Hinjewadi, Pune, Maharashtra 411057, India' },
  { name: 'RapidCharge Baner', address: 'Main Road, Baner, Pune, Maharashtra 411045, India' },
  { name: 'MetroEV Aundh', address: 'Kashibai Navale Rd, Aundh, Pune, Maharashtra 411007, India' },
  { name: 'ChargePoint Shivajinagar', address: 'Shivajinagar, Pune, Maharashtra 411005, India' }
];

async function run() {
  let conn;
  try {
    conn = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'vishal36646',
      database: 'ev_charging_system',
    });

    for (const u of updates) {
      const [rows] = await conn.execute('SELECT station_id FROM stations WHERE station_name = ?', [u.name]);
      if (!rows || rows.length === 0) { console.log('Station not found, skipping:', u.name); continue; }
      const id = rows[0].station_id;
      await conn.execute('UPDATE stations SET address = ? WHERE station_id = ?', [u.address, id]);
      console.log('Updated address for', u.name);
    }

  } catch (err) {
    console.error('Failed to update addresses:', err.message || err);
    process.exitCode = 1;
  } finally {
    if (conn) await conn.end();
  }
}

run();
