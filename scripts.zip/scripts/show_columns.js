import mysql from 'mysql2/promise';

async function show(tables) {
  const conn = await mysql.createConnection({ host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' });
  try {
    for (const t of tables) {
      const [rows] = await conn.execute(`SHOW COLUMNS FROM ${t}`);
      console.log(t + ': ' + rows.map(r => r.Field).join(', '));
    }
  } catch (err) { console.error('err', err.message || err); }
  finally { await conn.end(); }
}

show(['bookings','vehicles','charger_usage_log','slots','stations','users']);
