#!/usr/bin/env node
import mysql from 'mysql2/promise';

async function main(){
  const cfg = { host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' };
  let conn;
  try {
    conn = await mysql.createConnection(cfg);
    console.log('Connected to DB');

    // 1) create test user
    const [uRes] = await conn.query('INSERT INTO users (name, email, password) VALUES (?,?,?)', ['Test User','test.user+auto@example.com','testpass']);
    const userId = uRes.insertId;
    console.log('Inserted test user id=', userId);

    // 2) ensure there is at least one station to attach slot to
    const [stations] = await conn.query('SELECT station_id FROM stations ORDER BY station_id LIMIT 1');
    let stationId = stations && stations[0] && stations[0].station_id ? stations[0].station_id : null;
    if (!stationId) {
      const [sRes] = await conn.query('INSERT INTO stations (station_name, address) VALUES (?,?)', ['Auto Station','Auto Address']);
      stationId = sRes.insertId;
      console.log('Created station id=', stationId);
    }

    // 3) insert an available slot
    const slotNumber = 'TEST-' + Date.now()%10000;
    const [slotRes] = await conn.query('INSERT INTO slots (station_id, slot_number, status) VALUES (?,?,?)', [stationId, slotNumber, 'available']);
    const slotId = slotRes.insertId;
    console.log('Inserted slot id=', slotId, 'number=', slotNumber);

    // 4) call stored procedure to create booking
    console.log('Calling create_booking procedure...');
    await conn.query('CALL create_booking(?,?,?,?,?,?)', [userId, null, slotId, new Date().toISOString().slice(0,10), '10:00:00', '10:30:00']);

    // 5) get latest booking id
    const [lidRows] = await conn.query('SELECT LAST_INSERT_ID() as bookingId');
    const bookingId = lidRows && lidRows[0] && lidRows[0].bookingId ? lidRows[0].bookingId : null;
    console.log('BookingId (LAST_INSERT_ID) =', bookingId);

    // 6) query charger_usage_log for entries with this booking id
    const [logs] = await conn.query('SELECT * FROM charger_usage_log WHERE booking_id = ? ORDER BY log_id DESC', [bookingId]);
    console.log('Charger usage log entries for booking:', logs.length);
    console.dir(logs, { depth: null, colors: false });

    // 7) check slot status
    const [slotRows] = await conn.query('SELECT slot_id, status FROM slots WHERE slot_id = ?', [slotId]);
    console.log('Slot status after booking:', slotRows && slotRows[0] ? slotRows[0].status : 'not found');

    // cleanup note (not deleting test data to keep audit) -- optionally delete
    await conn.end();
    process.exit(0);
  } catch (err) {
    console.error('Test failed:', err && err.message ? err.message : err);
    if (conn) await conn.end().catch(()=>{});
    process.exit(1);
  }
}

main();
