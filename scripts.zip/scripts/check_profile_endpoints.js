import mysql from 'mysql2/promise';
// use global fetch available in modern Node

async function run() {
  const conn = await mysql.createConnection({ host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' });
  try {
    const [rows] = await conn.execute('SELECT user_id, email FROM users ORDER BY user_id DESC LIMIT 1');
    if (!rows || rows.length === 0) { console.log('No users found'); process.exit(0); }
    const user = rows[0];
    console.log('Latest user:', user);

    try {
      const userRes = await fetch(`http://localhost:3000/api/users/${user.user_id}`);
      console.log('/api/users status', userRes.status);
      const userJson = await userRes.text();
      console.log('/api/users response:', userJson);
    } catch (e) {
      console.error('/api/users fetch error', e.message);
    }

    try {
      const statsRes = await fetch(`http://localhost:3000/api/users/${user.user_id}/stats`);
      console.log('/api/users/:id/stats status', statsRes.status);
      const statsJson = await statsRes.text();
      console.log('/api/users/:id/stats response:', statsJson);
    } catch (e) {
      console.error('/api/users/:id/stats fetch error', e.message);
    }

  } catch (err) {
    console.error('Check error', err.message || err);
  } finally {
    await conn.end();
  }
}

run();
