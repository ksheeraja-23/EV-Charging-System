import mysql from 'mysql2/promise';

async function run() {
  let conn;
  try {
    conn = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'vishal36646',
      database: 'ev_charging_system',
    });

    console.log('Finding stations with "Demo" in the name...');
    const [rows] = await conn.execute("SELECT station_id, station_name FROM stations WHERE station_name LIKE '%Demo%' OR station_name LIKE '%demo%'");
    if (!rows || rows.length === 0) {
      console.log('No demo stations found. Nothing to do.');
      return;
    }

    for (const r of rows) {
      const newName = r.station_name.includes('(removed)') ? r.station_name : `${r.station_name} (removed)`;
      try {
        await conn.execute('UPDATE stations SET station_name = ? WHERE station_id = ?', [newName, r.station_id]);
        console.log(`Marked station_id=${r.station_id} as removed: ${newName}`);
      } catch (uErr) {
        console.warn('Failed to mark station', r.station_id, uErr.message || uErr);
      }
    }
  } catch (err) {
    console.error('Error connecting or updating DB:', err.message || err);
    process.exitCode = 1;
  } finally {
    if (conn) await conn.end();
  }
}

run();
