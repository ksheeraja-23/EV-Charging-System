// Simple test: register -> login -> get profile -> get stats
(async () => {
  try {
    const email = `regtest+${Date.now()}@example.com`;
    const password = 'testpass123';
    const base = 'http://localhost:3000';

    console.log('Registering:', email);
    let res = await fetch(base + '/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'API Test', email, phone: '9999999999', password, address: 'Test City' })
    });
    const reg = await res.text();
    console.log('/api/register status', res.status, 'body:', reg);
    if (!res.ok) return process.exit(1);
    const regJson = JSON.parse(reg);
    const userId = regJson.userId;

    console.log('Logging in...');
    res = await fetch(base + '/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password })
    });
    const loginText = await res.text();
    console.log('/api/login status', res.status, 'body:', loginText);
    if (!res.ok) return process.exit(1);
    const loginJson = JSON.parse(loginText);
    const loginUserId = loginJson.userId || userId;

    console.log('Fetching profile for userId=', loginUserId);
    res = await fetch(base + `/api/users/${loginUserId}`);
    console.log('/api/users status', res.status);
    console.log('profile:', await res.text());

    res = await fetch(base + `/api/users/${loginUserId}/stats`);
    console.log('/api/users/:id/stats status', res.status);
    console.log('stats:', await res.text());

    console.log('API register/login/profile test completed successfully');
    process.exit(0);
  } catch (err) {
    console.error('Test error', err);
    process.exit(1);
  }
})();
