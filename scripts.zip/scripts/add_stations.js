import mysql from 'mysql2/promise';

const stations = [
  {
    station_name: 'GreenCharge Pune - Kalyani Nagar',
    address: 'Survey 45, Kalyani Nagar, Pune, Maharashtra 411014, India',
    contact_no: '+91 20 1234 5678',
    location: 'Pune - Kalyani Nagar',
    image: 'https://images.unsplash.com/photo-1599058917218-7d7f2e92b3f8?w=1200&q=80&auto=format&fit=crop'
  },
  {
    station_name: 'CityVolt Hinjewadi',
    address: 'Phase 3, Hinjewadi, Pune, Maharashtra 411057, India',
    contact_no: '+91 20 2345 6789',
    location: 'Pune - Hinjewadi',
    image: 'https://images.unsplash.com/photo-1519741491358-4f8d9cf0c3b3?w=1200&q=80&auto=format&fit=crop'
  },
  {
    station_name: 'RapidCharge Baner',
    address: 'Main Road, Baner, Pune, Maharashtra 411045, India',
    contact_no: '+91 20 3456 7890',
    location: 'Pune - Baner',
    image: 'https://images.unsplash.com/photo-1542223616-6c5fb4a6bcd7?w=1200&q=80&auto=format&fit=crop'
  },
  {
    station_name: 'MetroEV Aundh',
    address: 'Kashibai Navale Rd, Aundh, Pune, Maharashtra 411007, India',
    contact_no: '+91 20 4567 8901',
    location: 'Pune - Aundh',
    image: 'https://images.unsplash.com/photo-1542365887-55b5371fb8a6?w=1200&q=80&auto=format&fit=crop'
  },
  {
    station_name: 'ChargePoint Shivajinagar',
    address: 'Shivajinagar, Pune, Maharashtra 411005, India',
    contact_no: '+91 20 5678 9012',
    location: 'Pune - Shivajinagar',
    image: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?w=1200&q=80&auto=format&fit=crop'
  }
];
async function run() {
  let connection;
  try {
    connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'vishal36646',
      database: 'ev_charging_system',
    });

  console.log('Removing or marking any Demo stations (if present)...');
    try {
      await connection.execute("DELETE FROM stations WHERE station_name LIKE '%Demo%'");
      console.log('Demo stations deleted (no FK conflicts)');
    } catch (delErr) {
      console.warn('Could not delete demo stations (likely FK references exist). Marking them as removed instead.');
      try {
        await connection.execute("UPDATE stations SET station_name = CONCAT(station_name, ' (removed)'), address = CONCAT(IFNULL(address,''), ' [removed]') WHERE station_name LIKE '%Demo%'");
        console.log('Demo stations marked as removed');
      } catch (uErr) {
        console.warn('Failed to mark demo stations as removed', uErr.message || uErr);
      }
    }

    // Inspect station columns to build safe insert (some deployments may have different schema)
    const [colRows] = await connection.execute('SHOW COLUMNS FROM stations');
    const availableCols = colRows.map(c => c.Field);
    const desired = ['station_name', 'address', 'contact_no', 'location', 'image'];
    const toInsertCols = desired.filter(c => availableCols.includes(c));

    if (toInsertCols.length === 0) {
      console.warn('Stations table appears to have no supported columns to insert. Aborting seed.');
      return;
    }

    let inserted = 0;
    let skipped = 0;
    for (const s of stations) {
      const [rows] = await connection.execute('SELECT station_id FROM stations WHERE station_name = ?', [s.station_name]);
      if (rows && rows.length > 0) {
        skipped++;
        console.log('Skipping (already present):', s.station_name);
        continue;
      }

      // Build placeholders & params based on available columns
      const placeholders = toInsertCols.map(_ => '?').join(',');
      const sql = `INSERT INTO stations (${toInsertCols.join(',')}) VALUES (${placeholders})`;
      const params = toInsertCols.map(col => s[col] || null);
      try {
        await connection.execute(sql, params);
        inserted++;
        console.log('Inserted station:', s.station_name);
      } catch (insErr) {
        console.warn('Insert error for', s.station_name, insErr.message || insErr);
      }
    }

    console.log(`Done. Inserted: ${inserted}, Skipped (already present): ${skipped}`);
  } catch (err) {
    console.error('Seeding failed:', err.message || err);
    process.exit(1);
  } finally {
    if (connection) await connection.end();
  }
}

run();
