import mysql from 'mysql2';
import fs from 'fs';
import path from 'path';

const sqlPath = path.join(process.cwd(), 'sql', 'init_schema.sql');
let sql = fs.readFileSync(sqlPath, 'utf8');

// Preprocess SQL to remove DELIMITER markers and replace $$ blocks with proper ';' terminators
// The mysql2 client does not understand the `DELIMITER` directive used by the mysql CLI.
// Strategy: remove any lines that start with DELIMITER and replace trailing '$$' markers with ';'
sql = sql.replace(/DELIMITER\s+\$\$/g, '');
sql = sql.replace(/DELIMITER\s+;/g, '');
// Replace "END $$" (or ") $$" endings) with "END;" and standalone "$$" with ";"
sql = sql.replace(/\s*\$\$\s*/g, ';');
// Some editors may left windows CRLF; normalize to \n
sql = sql.replace(/\r\n/g, '\n');
// Collapse multiple semicolons into single
sql = sql.replace(/;{2,}/g, ';');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'vishal36646',
  database: 'ev_charging_system',
  multipleStatements: true
});

db.connect((err) => {
  if (err) return console.error('Migration DB connect error:', err);
  console.log('Connected to DB for migration');

  db.query(sql, (err) => {
    if (err) {
      console.error('Migration error:', err.message || err);
      process.exit(1);
    }
    console.log('Migration applied successfully');
    process.exit(0);
  });
});
