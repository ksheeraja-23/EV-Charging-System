import mysql from 'mysql2/promise';

async function run() {
  const conn = await mysql.createConnection({ host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' });
  try {
    const [cols] = await conn.execute('SHOW COLUMNS FROM bookings');
    const colNames = cols.map(c => c.Field);
    if (!colNames.includes('vehicle_id')) {
      console.log('Adding vehicle_id column to bookings');
      await conn.execute('ALTER TABLE bookings ADD COLUMN vehicle_id INT NULL AFTER user_id');
      // Add FK if vehicles table exists
      const [vcols] = await conn.execute("SHOW TABLES LIKE 'vehicles'");
      if (vcols.length > 0) {
        try {
          await conn.execute('ALTER TABLE bookings ADD CONSTRAINT fk_bookings_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)');
        } catch (e) { console.warn('Could not add FK:', e.message || e); }
      }
      console.log('Done');
    } else {
      console.log('vehicle_id already present');
    }
  } catch (err) { console.error('Error', err.message || err); }
  finally { await conn.end(); }
}

run();
