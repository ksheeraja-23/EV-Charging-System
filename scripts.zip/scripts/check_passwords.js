import mysql from 'mysql2/promise';
(async function(){
  try {
    const db = await mysql.createConnection({ host: 'localhost', user: 'root', password: 'vishal36646', database: 'ev_charging_system' });
    const [rows] = await db.execute('SELECT user_id, email, password FROM users');
    let bcryptCount = 0, plainCount = 0, emptyCount = 0;
    for (const r of rows) {
      const pw = r.password || '';
      if (pw.length === 0) emptyCount++;
      else if (pw.startsWith('$2a$') || pw.startsWith('$2b$') || pw.startsWith('$2y$')) bcryptCount++;
      else plainCount++;
    }
    console.log('users total:', rows.length, 'bcrypt:', bcryptCount, 'plain:', plainCount, 'empty:', emptyCount);
    await db.end();
    process.exit(0);
  } catch (err) {
    console.error('Error checking passwords', err.message || err);
    process.exit(2);
  }
})(); 