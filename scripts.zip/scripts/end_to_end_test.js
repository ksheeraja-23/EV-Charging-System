import mysql from 'mysql2/promise';

async function run() {
  const conn = await mysql.createConnection({ host:'localhost', user:'root', password:'vishal36646', database:'ev_charging_system' });
  try {
    // 1) Create test user
  const uniqueEmail = `e2e-test+${Date.now()}@example.com`;
  const [u] = await conn.execute('INSERT INTO users (name,email,password) VALUES (?,?,?)', ['E2E Test', uniqueEmail, 'pass123']);
    const userId = u.insertId;

    // 2) Add vehicle
    const [v] = await conn.execute('INSERT INTO vehicles (user_id, vehicle_no, model, type, battery_capacity) VALUES (?,?,?,?,?)', [userId, 'E2E-1234', 'Model X', '4W', '75 kWh']);
    const vehicleId = v.insertId;

    // 3) Find an available slot
    const [slots] = await conn.execute("SELECT slot_id FROM slots WHERE status='available' LIMIT 1");
    if (!slots || slots.length === 0) { console.error('No available slots'); process.exit(1); }
    const slotId = slots[0].slot_id;

    // 4) Call stored procedure create_booking
    const today = new Date();
    const bookingDate = today.toISOString().slice(0,10);
    const startTime = '10:00:00';
    const endTime = '10:30:00';
    await conn.query('CALL create_booking(?,?,?,?,?,?)', [userId, vehicleId, slotId, bookingDate, startTime, endTime]);

    // 5) Fetch bookings for user
    const [bookings] = await conn.execute('SELECT * FROM bookings WHERE user_id = ?', [userId]);
    const [usage] = await conn.execute('SELECT * FROM charger_usage_log WHERE user_id = ?', [userId]);

    console.log('userId', userId, 'vehicleId', vehicleId, 'slotId', slotId);
    console.log('bookings', bookings);
    console.log('usage', usage);

  } catch (err) {
    console.error('E2E error', err.message || err);
  } finally {
    await conn.end();
  }
}

run();
