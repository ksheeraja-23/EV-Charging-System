// ===================== Constants =====================
const LOCAL_STORAGE_KEYS = {
    IS_LOGGED_IN: 'isLoggedIn',
    CURRENT_USER_ID: 'ev_user_id',
    STATIONS: 'stations',
    VEHICLES: 'vehicles'
};

const API_ENDPOINTS = {
    STATIONS: '/api/stations',
    VEHICLES: '/api/vehicles'
};

// Add auth endpoints
API_ENDPOINTS.LOGIN = '/api/login';
API_ENDPOINTS.REGISTER = '/api/register';
API_ENDPOINTS.USER = '/api/users'; // usage: /api/users/:userId
API_ENDPOINTS.USER_STATS = '/api/users'; // usage: /api/users/:userId/stats

// ===================== Utility Functions =====================

// Check if user is logged in
function checkAuth() {
    const isLoggedIn = localStorage.getItem(LOCAL_STORAGE_KEYS.IS_LOGGED_IN);
    const currentPage = window.location.pathname.split('/').pop();
    
    // Define an array of public pages for clarity
    const publicPages = ['index.html', '']; // '' handles the root path '/'

    if (!isLoggedIn && !publicPages.includes(currentPage)) {
        window.location.href = 'index.html';
        return;
    }

    // If a user is logged in, prevent non-admins from accessing admin.html
    const role = localStorage.getItem('ev_user_role') || null;
    if (currentPage === 'admin.html' && role !== 'admin') {
        // not authorized
        window.location.href = 'profile.html';
    }
}

function getCurrentUserId() {
    return localStorage.getItem(LOCAL_STORAGE_KEYS.CURRENT_USER_ID);
}

// Toast popup message
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Format date
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Format date + time
function formatDateTime(dateString) {
    return new Date(dateString).toLocaleString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// ===================== Fetch Data from Backend (Refactored) =====================

/**
 * Generic function to fetch data, handle errors, and cache to localStorage.
 * @param {string} endpoint - The API endpoint to fetch from.
 * @param {string} cacheKey - The localStorage key to store the data under.
 * @param {string} errorMessage - The error message for the console and toast.
 * @returns {Promise<Array<any>>} The fetched data array or an empty array on error.
 */
async function cachedFetch(endpoint, cacheKey, errorMessage) {
    try {
        const res = await fetch(endpoint);
        if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const data = await res.json();
        localStorage.setItem(cacheKey, JSON.stringify(data)); // Cache
        return data;
    } catch (err) {
        console.error(errorMessage, err);
        showToast(`Error: ${errorMessage}!`);
        return []; // Return empty array to prevent downstream crashes
    }
}

// Fetch all stations from backend (returns array)
async function fetchStations() {
    return cachedFetch(
        API_ENDPOINTS.STATIONS, 
        LOCAL_STORAGE_KEYS.STATIONS, 
        "Failed to load stations"
    );
}

// Fetch all vehicles from backend (returns array)
async function fetchVehicles() {
    return cachedFetch(
        API_ENDPOINTS.VEHICLES, 
        LOCAL_STORAGE_KEYS.VEHICLES, 
        "Failed to load vehicles"
    );
}

// ===================== Replace mockData lookups (Refactored) =====================

/**
 * Generic function to look up an item property from cache or fetch new data.
 * @param {string} cacheKey - The localStorage key (e.g., LOCAL_STORAGE_KEYS.STATIONS).
 * @param {Function} fetchFunction - The async function to fetch data if cache is empty (e.g., fetchStations).
 * @param {string} id - The ID to search for (e.g., 'S001').
 * @param {string} idKey - The key for the ID property (e.g., 'station_id').
 * @param {string} valueKey - The key for the value property to return (e.g., 'station_name').
 * @param {string} defaultValue - The value to return if not found.
 * @returns {Promise<string>} The requested property value or the default value.
 */
async function getLookupItem(cacheKey, fetchFunction, id, idKey, valueKey, defaultValue = 'Unknown') {
    // Try cache first
    let items = JSON.parse(localStorage.getItem(cacheKey));

    // If cache is empty or fetch was unsuccessful (returned []), fetch data
    if (!items || items.length === 0) {
        items = await fetchFunction();
    }

    const item = items.find(i => i[idKey] === id);
    return item ? item[valueKey] : defaultValue;
}

async function getStationName(stationId) {
    return getLookupItem(
        LOCAL_STORAGE_KEYS.STATIONS,
        fetchStations,
        stationId,
        'station_id',
        'station_name'
    );
}

async function getVehicleModel(vehicleId) {
    return getLookupItem(
        LOCAL_STORAGE_KEYS.VEHICLES,
        fetchVehicles,
        vehicleId,
        'vehicle_id',
        'model'
    );
}

// ===================== Navigation Highlight =====================

function setActiveNav() {
    const currentPage = window.location.pathname.split('/').pop();
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach(item => {
        const href = item.getAttribute('href');
        // Use endsWith for robust check, handles paths like /folder/profile.html
        if (href.endsWith(currentPage)) {
            item.classList.add('active');
        }
    });
}

// ===================== Initialization =====================

if (window.location.pathname !== '/' && !window.location.pathname.endsWith('index.html')) {
    checkAuth();
    window.addEventListener('DOMContentLoaded', setActiveNav);
}

// ===================== Logout =====================

function logout() {
    localStorage.removeItem(LOCAL_STORAGE_KEYS.IS_LOGGED_IN);
    window.location.href = 'index.html';
}

// ===================== Login Handler =====================

// Check if the current page is index.html (login page)
if (window.location.pathname.endsWith('index.html') || window.location.pathname === '/') {
    
    // Add event listener once the HTML is fully loaded
    window.addEventListener('DOMContentLoaded', () => {
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        const showRegister = document.getElementById('showRegister');
        // Toggle register / login
        if (showRegister) {
            showRegister.addEventListener('click', (e) => {
                e.preventDefault();
                const rf = document.getElementById('registerForm');
                if (rf.style.display === 'none' || rf.style.display === '') {
                    rf.style.display = 'block';
                    loginForm.style.display = 'none';
                } else {
                    rf.style.display = 'none';
                    loginForm.style.display = 'block';
                }
            });
        }
        
        // Ensure the form exists before trying to add a listener
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Use the constant if you implemented the refactoring, otherwise 'isLoggedIn'
                const isLoggedInKey = 'isLoggedIn'; 
                
                const email = document.getElementById('email').value.trim();
                const password = document.getElementById('password').value.trim();
                
                if (email && password) {
                    // Call backend login
                    fetch(API_ENDPOINTS.LOGIN, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email, password })
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data && data.success && data.userId) {
                            localStorage.setItem(isLoggedInKey, 'true');
                            localStorage.setItem(LOCAL_STORAGE_KEYS.CURRENT_USER_ID, data.userId);
                            // store role if returned for admin redirect
                            if (data.role) localStorage.setItem('ev_user_role', data.role);
                            showToast('Login Successful! Redirecting...');
                            setTimeout(() => { 
                                const role = localStorage.getItem('ev_user_role');
                                if (role === 'admin') window.location.href = 'admin.html';
                                else window.location.href = 'profile.html';
                            }, 600);
                        } else {
                            showToast(data.message || 'Invalid credentials');
                        }
                    })
                    .catch(err => {
                        console.error('Login error', err);
                        showToast('Login failed, try again');
                    });
                } else {
                    showToast('Error: Please enter both email and password.');
                }
            });
        }
    });
}

// Registration handler
if (window.location.pathname.endsWith('index.html') || window.location.pathname === '/') {
    window.addEventListener('DOMContentLoaded', () => {
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const name = document.getElementById('reg_name').value.trim();
                const email = document.getElementById('reg_email').value.trim();
                const phone = document.getElementById('reg_phone').value.trim();
                const password = document.getElementById('reg_password').value.trim();
                const address = document.getElementById('reg_address').value.trim();

                if (!name || !email || !password) {
                    showToast('Please fill name, email and password');
                    return;
                }

                fetch(API_ENDPOINTS.REGISTER, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, email, phone, password, address })
                })
                .then(async (res) => {
                    if (res.status === 201) return res.json();
                    const err = await res.json().catch(() => ({}));
                    throw new Error(err.message || 'Registration failed');
                })
                .then(data => {
                    showToast('Registration successful! Logging you in...');
                    localStorage.setItem(LOCAL_STORAGE_KEYS.IS_LOGGED_IN, 'true');
                    localStorage.setItem(LOCAL_STORAGE_KEYS.CURRENT_USER_ID, data.userId);
                    setTimeout(() => { window.location.href = 'profile.html'; }, 900);
                })
                .catch(err => {
                    console.error('Register error', err);
                    showToast(err.message || 'Registration failed');
                });
            });
        }
    });
}

// Load profile data (used on profile.html)
async function loadProfile() {
    const userId = getCurrentUserId();
    console.log('loadProfile: current userId=', userId);
    if (!userId) {
        window.location.href = 'index.html';
        return;
    }

    try {
        console.log('loadProfile: fetching /api/users/' + userId);
        const [userRes, statsRes] = await Promise.all([
            fetch(`${API_ENDPOINTS.USER}/${userId}`),
            fetch(`${API_ENDPOINTS.USER}/${userId}/stats`)
        ]);

        console.log('loadProfile: fetched responses', userRes.status, statsRes.status);

        if (!userRes.ok) throw new Error('Failed to fetch user');
        const user = await userRes.json();
        const stats = statsRes.ok ? await statsRes.json() : { totalBookings:0, totalEnergy:0, totalSavings:0 };

        // Populate profile fields if elements exist
        const nameEl = document.getElementById('userName');
        const emailEl = document.getElementById('userEmail');
        const phoneEl = document.getElementById('userPhone');
        const roleEl = document.getElementById('userRole');
        const avatarEl = document.getElementById('userAvatar');

        if (nameEl) nameEl.textContent = user.name || user.email || 'Evion User';
        if (emailEl) emailEl.textContent = user.email || '';
        if (phoneEl) phoneEl.textContent = user.phone || '—';
        if (roleEl) roleEl.textContent = user.role || 'Member';
        if (avatarEl) avatarEl.src = user.avatar || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user.name || user.email || 'U');

        // Stats
        const statsCards = document.querySelectorAll('.stat-card');
        if (statsCards && statsCards.length >= 3) {
            statsCards[0].querySelector('.value').textContent = stats.totalBookings ?? '0';
            statsCards[1].querySelector('.value').innerHTML = (stats.totalEnergy ?? 0) + ' <span style="font-size:1.2rem">kWh</span>';
            statsCards[2].querySelector('.value').textContent = '₹' + (stats.totalSavings ?? 0);
        }

    } catch (err) {
        console.error('Error loading profile', err);
        showToast('Unable to load profile');
    }
}

// Fetch vehicles for a user
async function fetchUserVehicles(userId) {
    try {
        const res = await fetch(`/api/vehicles/${userId}`);
        if (!res.ok) return [];
        return await res.json();
    } catch (err) { return []; }
}

// Create a booking (calls backend stored procedure)
async function createBooking(payload) {
    try {
        const res = await fetch('/api/bookings', {
            method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
        });
        return await res.json();
    } catch (err) { console.error('createBooking error', err); return { error: err.message }; }
}

// Add a vehicle
async function addVehicle(payload) {
    try {
        const res = await fetch('/api/vehicles', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        return await res.json();
    } catch (err) { console.error('addVehicle error', err); return { error: err.message }; }
}

// Create payment
async function createPayment(payload) {
    try {
        const res = await fetch('/api/payments', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        return await res.json();
    } catch (err) { console.error('createPayment error', err); return { error: err.message }; }
}

// Submit feedback
async function submitFeedback(payload) {
    try {
        const res = await fetch('/api/feedback', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        return await res.json();
    } catch (err) { console.error('submitFeedback error', err); return { error: err.message }; }
}

// Fetch bookings for a user
async function fetchBookings(userId) {
    try { const r = await fetch(`/api/bookings/${userId}`); if (!r.ok) return []; return await r.json(); } catch(e){return []}
}

// Fetch payments for a user
async function fetchPayments(userId) {
    try { const r = await fetch(`/api/payments/${userId}`); if (!r.ok) return []; return await r.json(); } catch(e){return []}
}